import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

export default function Teste() {
    return (
        <Text>OUREGHEROIUGHUREÇOG</Text>
    )
}