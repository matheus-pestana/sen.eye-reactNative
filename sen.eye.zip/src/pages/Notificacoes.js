import React from 'react';
<<<<<<< HEAD
import { View, Text, StyleSheet, Image, SafeAreaView, ScrollView, Dimensions } from 'react-native';

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
=======
import { View, Text, StyleSheet, Image, SafeAreaView, ScrollView } from 'react-native';
>>>>>>> 6dabb2b0c3636f33eec629b6ef71b5a9bac7b065

export default function Notificacoes() {
    return (
        <SafeAreaView style={styles.safeArea}>
<<<<<<< HEAD
            <View style={styles.container}>
                <View style={styles.header}>
                    <Image source={require('../assets/logo1.png')} style={styles.logo} />
                    <Text style={styles.headerText}>Notificações</Text>
                </View>
                <View style={styles.notificationBackgroundWrapper}>
                    <View style={styles.notificationBackground}>
                        <ScrollView contentContainerStyle={styles.scrollContainer}>
                            <View style={styles.notificationBox}>
                                <Image source={require('../assets/sino.png')} style={styles.icon} />
                                <View style={styles.notificationContent}>
                                    <View style={styles.notificationHeader}>
                                        <Text style={styles.notificationTitle}>Notificação</Text>
                                        <Text style={styles.notificationDate}>15/02/2024 15:36</Text>
                                    </View>
                                    <Text style={styles.notificationMessage}>
                                        Nosso sistema está passando por uma manutenção não se preocupe não afetará em nada na funcionalidade do aplicativo.
                                    </Text>
                                </View>
                            </View>
                            <View style={styles.notificationBox}>
                                <Image source={require('../assets/alerta.png')} style={styles.icon} />
                                <View style={styles.notificationContent}>
                                    <View style={styles.notificationHeader}>
                                        <Text style={styles.notificationTitle}>Alerta!</Text>
                                        <Text style={styles.notificationDate}>15/02/2024 15:36</Text>
                                    </View>
                                    <Text style={styles.notificationMessage}>
                                        A Avenida Brasil (Caçapava-SP) está alagada, fique em casa, fortes chuvas estão previstas para acontecer as 16:30.
                                    </Text>
                                </View>
                            </View>
                        </ScrollView>
                    </View>
                </View>
            </View>
=======
            <View style={styles.header}>
                <Image source={require('../assets/logo.webp')} style={styles.logo} />
                <Text style={styles.headerText}>Notificações</Text>
            </View>
            <View style={styles.notificationBackgroundWrapper}>
                <View style={styles.notificationBackground}>
                    <ScrollView contentContainerStyle={styles.scrollContainer}>
                        <View style={styles.notificationBox}>
                            <Image source={require('../assets/sino.png')} style={styles.icon} />
                            <View style={styles.notificationContent}>
                                <View style={styles.notificationHeader}>
                                    <Text style={styles.notificationTitle}>Notificação</Text>
                                    <Text style={styles.notificationDate}>15/02/2024 15:36</Text>
                                </View>
                                <Text style={styles.notificationMessage}>
                                    Nosso sistema está passando por uma manutenção não se preocupe não afetará em nada na funcionalidade do aplicativo.
                                </Text>
                            </View>
                        </View>
                        <View style={styles.notificationBox}>
                            <Image source={require('../assets/alerta.png')} style={styles.icon} />
                            <View style={styles.notificationContent}>
                                <View style={styles.notificationHeader}>
                                    <Text style={styles.notificationTitle}>Alerta!</Text>
                                    <Text style={styles.notificationDate}>15/02/2024 15:36</Text>
                                </View>
                                <Text style={styles.notificationMessage}>
                                    A Avenida Brasil (Caçapava-SP) está alagada, fique em casa, fortes chuvas estão previstas para acontecer as 16:30.
                                </Text>
                            </View>
                        </View>
                    </ScrollView>
                </View>
            </View>
>>>>>>> 6dabb2b0c3636f33eec629b6ef71b5a9bac7b065
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
<<<<<<< HEAD
=======
        backgroundColor: '#7D99B8',
>>>>>>> 6dabb2b0c3636f33eec629b6ef71b5a9bac7b065
        flex: 1,
        backgroundColor: '#7D99B8',
    },
<<<<<<< HEAD

    container: {
        flex: 1,
        paddingVertical: 30,
    },

    header: {
        flexDirection: 'row',
        justifyContent: 'center',
=======
    header: {
        flexDirection: 'row',
>>>>>>> 6dabb2b0c3636f33eec629b6ef71b5a9bac7b065
        alignItems: 'center',
        padding: 10,
    },
    logo: {
<<<<<<< HEAD
        width: 50,
        height: 50,
        marginRight: 70,
=======
        width: 40,
        height: 40,
        marginRight: 10,
>>>>>>> 6dabb2b0c3636f33eec629b6ef71b5a9bac7b065
    },
    headerText: {
        fontSize: 20,
        fontWeight: 'bold',
<<<<<<< HEAD
        textAlign: 'center',
        marginRight: 120,
=======
        flex: 1,
        textAlign: 'center',
        marginRight: 40,
>>>>>>> 6dabb2b0c3636f33eec629b6ef71b5a9bac7b065
    },
    notificationBackgroundWrapper: {
        flex: 1,
        paddingHorizontal: 20,
        paddingTop: 30,
        paddingBottom: 100,
    },
    notificationBackground: {
        flex: 1,
        backgroundColor: '#6B8CAA',
        borderRadius: 10,
        paddingVertical: 10,
        paddingHorizontal: 10,
    },
    scrollContainer: {
        alignItems: 'center',
    },
    notificationBox: {
        width: '90%',
        backgroundColor: '#fff',
        borderRadius: 10,
        padding: 15,
        marginVertical: 10,
        flexDirection: 'row',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 2,
        elevation: 3,
    },
    icon: {
        width: 40,
        height: 40,
        marginRight: 10,
    },
    notificationContent: {
        flex: 1,
    },
    notificationHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    notificationTitle: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    notificationDate: {
        fontSize: 10,
        color: '#888',
    },
    notificationMessage: {
        marginTop: 5,
        fontSize: 14,
        color: '#555',
    },
<<<<<<< HEAD
});
=======
});

>>>>>>> 6dabb2b0c3636f33eec629b6ef71b5a9bac7b065
